﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Textospeach.Models
{
    public class TextModel
    {
        public string Text { get; set; }
    }
}